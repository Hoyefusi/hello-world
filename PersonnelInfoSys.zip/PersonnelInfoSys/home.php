<?php
	include("session.php");
	
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/mystyle.css" /> 

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.hoverIntent.js"></script>
<script type="text/javascript" src="scripts/jquery.hslides.1.0.js"></script>
<script type="text/javascript" src="scripts/jquery.hslides.setup.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />


<link href="theme/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="theme/1/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div class="icon-bar">
  <a class="active" href="home.php"><i class="fa fa-home"></i></a> 
  <a href="users.php"><i class="fa fa-user"></i></a> 
  <a href="registration.php"><i class="fa fa-registered"></i></a>
  <a href="print_all.php" target="_blank"><i class="fa fa-print"></i></a>
  <a href="logout.php"><i class="fa fa-power-off"></i></a> 
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!-- below are the body contents /-->
 <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
    </div>
    <br class="clear" />

<div id="featured_slide">

  <div class="wrapper">
    
    
 <div id="sliderFrame">
        
        <div id="slider">
      
                <img src="Images/redifined.png" alt="P.I.S, Service Registers of individuals in an organization." />
            <img src="Images/Access.png" alt="All details pertaining to Registered Personnel" />
            <img src="Images/fast.png" alt="Extract Valuable Informtion without stress" />
            <img src="Images/click.png" alt="Computer based Personnnel Information System" />
        </div>
    </div>  
  </div>   
  </div>
 
  
  <!-- below are the body contents /-->
 <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
    </div>
    <br class="clear" />
	
	 <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
    </div>
    <br class="clear" />
	 <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
    </div>
    <br class="clear" />
	 <br class="clear" />
	 <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
    </div>
    <br class="clear" />
	
<!-- below are the Information and paragraphs contents /-->
<div id="homecontent">
  <div class="wrapper">
    <ul>
      <li>
        <h2 class="title"><img src="images/server.png" alt="" />Personnel Details</h2>
        <p>The Personnel Information system is a Computer based system for maintenance of the. Service Registers of individuals in an organization. The details pertaining to personnel, postings, qualifications, departmental tests passed, training attended, family details etc are stored in this system.</p>
      </li>
      <li>
        <h2 class="title"><img src="images/user1.png" alt="" />Informationat its peak</h2>
        <p><img src="images/download1.jpg" alt="" width="277" height="122" /></p>
          <br />
        </p>
      </li>
	   <li class="last active">
        <h2 class="title"><img src="images/login.png" alt="" />Register Now</h2>
		<p class="readmore"><a href="registration.php">.Register Now &raquo;</a></p>
		</li>
    </ul>
    <br class="clear" />
  </div>
</div>

<!-- ####################################################################################################### -->
<div id="container">
  <div class="wrapper">
    <div id="content">
      <h2>About Personnel Information System</h2>
      <p>Personnel Information System (PIS) is a computerized database application that maintains and manage all the demographic and service profil of a civil servant. Simply put, the application is an electronic format of the �Sheet Roll� that every civil seant must fill up during his/her first appointment.</p>
      <p>The PIS maintains the vital information of an employee such as Sheet Roll Number name, date of birth, gender, maiden name, permanent address, Phone number.</p>
      <p>&nbsp; </p>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### --><!-- ####################################################################################################### -->
<div id="copyright">
  <div class="wrapper">
    <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved </p>
    <p class="fl_left">Shoetan Lawal PN/CS/15/0369</p>
    <p class="fl_left"><a href="#"></a></p>
    <br class="clear" />
  </div>
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
</script>
</body>
</html> 
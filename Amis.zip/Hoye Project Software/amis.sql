-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 06, 2017 at 02:35 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `amis`
--

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE IF NOT EXISTS `farmer` (
  `id` int(125) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(125) NOT NULL,
  `phone` varchar(125) NOT NULL,
  `password` varchar(125) NOT NULL,
  `email` varchar(125) NOT NULL,
  `occupation` varchar(125) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`id`, `fullname`, `phone`, `password`, `email`, `occupation`) VALUES
(1, 'Adesola Adesi', '07069039154', 'supernova', 'adesola@gmail.com', 'farmer'),
(2, 'Akinsola Sikemi', '09032978104', 'promisey', 'fiyinfoluwa@gmail.com', 'farmer');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(124) NOT NULL,
  `Password` varchar(124) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Username`, `Password`) VALUES
(1, 'Amis', 'supernova321');

-- --------------------------------------------------------

--
-- Table structure for table `product_farmer`
--

CREATE TABLE IF NOT EXISTS `product_farmer` (
  `Id` int(120) NOT NULL AUTO_INCREMENT,
  `productsname` varchar(150) NOT NULL,
  `quantity` varchar(150) NOT NULL,
  `description` varchar(150) NOT NULL,
  `occupation` varchar(150) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `product_trader`
--

CREATE TABLE IF NOT EXISTS `product_trader` (
  `Id` int(125) NOT NULL AUTO_INCREMENT,
  `productsname` varchar(150) NOT NULL,
  `quantity` varchar(150) NOT NULL,
  `description` varchar(150) NOT NULL,
  `occupation` varchar(150) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trader`
--

CREATE TABLE IF NOT EXISTS `trader` (
  `id` int(125) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(125) NOT NULL,
  `phone` varchar(125) NOT NULL,
  `password` varchar(125) NOT NULL,
  `email` varchar(125) NOT NULL,
  `occupation` varchar(125) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `trader`
--

INSERT INTO `trader` (`id`, `fullname`, `phone`, `password`, `email`, `occupation`) VALUES
(8, 'Oyefusi Damilare Festus', '07069039154', 'supernova', 'festusoyefusi@gmail.com', 'trader');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

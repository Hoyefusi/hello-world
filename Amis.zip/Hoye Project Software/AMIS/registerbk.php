<?php

	// Define $Registeration Details
	 $fullname=$_POST['fullname'];
	 $phone=$_POST['phone'];
	 $password=$_POST['password'];
	 $email=$_POST['email'];
	 $occupation=$_POST['dropdown'];
	// Establishing Connection with Server by passing server_name, user_id and password as a parameter
	require_once("admin/connect.php");
	

	if ($occupation=="farmer")
	{
	
		$qr = "SELECT * FROM farmer WHERE phone='$phone'";
	
	$rs = $connection->query($qr);
	
	if(mysqli_num_rows($rs) > 0){
		header("location: index.php?remark=alreadytaken");
		}
		else{
	//It wiil insert a row into Table Farmer DB`
$query = "INSERT INTO farmer(fullname, phone, password, email, occupation) 
	VALUES ('$fullname','$phone','$password','$email','$occupation')";

		$data = $connection->query($query ) or die($connection.error);
		header("location: index.php");
		}
	}
	else if($occupation=="trader")
	{
	
	$qr = "SELECT * FROM trader WHERE phone='$phone'";
	
	$rs = $connection->query($qr);
	
	if(mysqli_num_rows($rs) > 0){
		header("location: index.php?remark=alreadytaken");
		}
		else{
	//It wiil insert a row into Table Trader DB`
$query = "INSERT INTO trader(fullname, phone, password, email, occupation) 
	VALUES ('$fullname','$phone','$password','$email','$occupation')";
		$data = $connection->query($query) or die($connection.error);
		header("location: index.php");
		}
	}else
	{ header("location: index.php?remark=error"); }
	
?>
<?php
include('connect.php');
$Id =$_GET['id'];
mysqli_query($connection, "DELETE FROM `product_trader` WHERE `Id` = $Id") or die (mysqli_error());
header('location:view.php');
?>
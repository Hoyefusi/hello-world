 <?php
session_start();

include('connect.php');


if(isset($_SESSION['login_name'])){
	$name = $_SESSION['login_name'];


?>

<!DOCTYPE html>
<html>
<head>
<title>MESSAGE</title>
<link href="css/style.css" rel="stylesheet" type="text/css">

</head>

<body>
	
<div id="home">
<b id="welcome">Message : <i><?php echo $name; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>

<p></p>
<div id="menu1">
<h1>Agriculture Market Information System </h1>
<ul class="menu nav">

		<li><a href="dashboard.php">DASHBOARD</a></li>
		<li><a href="clientlogin.php">CLIENT PROFILE</a></li> 
		<li><a href="message.php">MESSAGE</a></li> 
		<li><a href="view.php">VIEW</a></li> 
  </ul>
</div>

 <?php
//allow remote access to this script, replace the * to your domain e.g http://www.example.com if you wish to recieve requests only from your server
header("Access-Control-Allow-Origin: *");
//rebuild form data
$postdata = http_build_query(
    array(
        'username' => isset($_POST["username"])? $_POST["username"]: $_GET["username"],
        'password' => isset($_POST["password"])?$_POST["password"]: $_GET["password"],
  'message' => isset($_POST["message"])?$_POST["message"]: $_GET["message"],
  'mobiles' => isset($_POST["to"])?$_POST["to"]: $_GET["to"],
  'sender' => isset($_POST["sender"])?$_POST["sender"]: $_GET["sender"],
    )
);
//prepare a http post request
$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
    )
);
//craete a stream to communicate with betasms api
$context  = stream_context_create($opts);
//get result from communication
$result = file_get_contents('http://login.betasms.com/api/', false, $context);
//return result to client, this will return the appropriate respond code
echo "<p align="center"><b>SMS Result</b><br/><b>Code: $result</b></b></p>";
?>
</div>

<footer>
		<div class="footer">
		&copy; festusoyefusi@gmail.com 2017. All right reserved.		</div>
</footer>

</body>
</html>

<?php } else { echo "Login Required";} ?>

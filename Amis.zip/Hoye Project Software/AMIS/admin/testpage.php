<?php
$date = date("Y-m-d G:i");
echo $date;
?><!-- 08/07/2017 13:31:17
08/07/2017 13:31:17
yyyy-mm-dd/hh:mm -->
<?php
session_start();

include('connect.php');


if(isset($_SESSION['login_name'])){
	$name = $_SESSION['login_name'];


?>

<!DOCTYPE html>
<html>
<head>
<title>MESSAGE</title>
<link href="css/style.css" rel="stylesheet" type="text/css">

</head>

<body>
	
<div id="home">
<b id="welcome">Message : <i><?php echo $name; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>

<p></p>
<div id="menu1">
<h1>Agriculture Market Information System </h1>
<ul class="menu nav">

		<li><a href="dashboard.php">DASHBOARD</a></li>
		<li><a href="clientlogin.php">CLIENT PROFILE</a></li> 
		<li><a href="message.php">MESSAGE</a></li> 
		<li><a href="view.php">VIEW</a></li> 
  </ul>
</div>


<div id="content" class"tblform">

<table align="center" width="800">
<form action="send_sms.php" method="post" name="message">
<th colspan="2" bordercolor="style:#000000"> Send Message <?php echo $name; ?></th>
<tr><td align="right"><td> <input type="hidden" name="username" value="festusoyefusi@gmail.com" /></td></tr>
<tr><td align="right"><td> <input type="hidden" name="password" value="supernova" /></td></tr>
<tr><td align="right"><label> Sender:</label> </td> <td> <input type="text" name="sender" value="Amis" /></td></tr>
<tr><td align="right"><label> To:</label></td> <td> <input type="text" name="to" Placeholder="e.g. 2347069039154" required="required" /></td></tr>
<tr><td align="right"><label> Message:</label></td> <td> <textarea cols="60" rows="5" name="message" Placeholder="This is where the message will be composed, to be sent to registered customer both farmer and traders based on update received" required="required" /></textarea></td></tr>
<!-- <tr><td align="right"><label>Occupation:</label></td> <td>  -->
											<!-- <Select name="dropdown"> -->
											<!-- <option > Select </option> -->
											<!-- <option value="trader" >Trader</option> -->
											<!-- <option value="farmer">Farmer</option> -->
											<!-- </Select></td></tr> -->
<tr><td align="right"><label> Send</label></td> <td> <input name="save" type="submit" value="Send"></td></tr>
</form>
</table>
</div>

<footer>
		<div class="footer">
		&copy; festusoyefusi@gmail.com 2017. All right reserved.		</div>
</footer>

</body>
</html>

<?php } else { echo "Login Required";} ?>
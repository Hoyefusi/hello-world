<?php
session_start();

include('connect.php');


if(isset($_SESSION['login_name'])){
	$name = $_SESSION['login_name'];


?>

<!DOCTYPE html >

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>VIEW PROFILE</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/mystyle1.css" /> 
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="home">
<b id="welcome">View Clients : <i><?php echo $name; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>

<p></p>
<div id="menu1">
<h1>Agriculture Market Information System </h1>
<ul class="menu nav">


		<li><a href="dashboard.php">DASHBOARD</a></li>
		<li><a href="clientlogin.php">CLIENT PROFILE</a></li>
		<div class="dropdown">
  		<button class="dropbtn">VIEW</button>
  		<div class="dropdown-content">
    	<a href="viewfarmer.php">FARMER</a>
   		<a href="viewtrader.php">TRADER</a>	
  		</div>
		</div>
		<li><a href="message.php">MESSAGE</a></li> 
  </ul>
</div>


<div id="menu1">
<h1 class="title style3">Traders Queries</h1>
</div>
<table>
<thead>
<tr>
	<th>ID </th>
	<th>FULL NAME</th>
	<th>PHONE</th>
	<th>PRODUCTS NAME</th>
	<th> QUANTITY </th>
	<th> DESCRIPTION </th>
	<th> DELETE </th>
	
	</tr>
	</thead>

<?php
require_once('connect.php');

$query = mysqli_query($connection, "SELECT * FROM `product_trader`");
while ($row = mysqli_fetch_array($query)){
$no = $row['Id'];
?>

<tr>
<td> <?php echo $row['Id']; ?> </td>
<td> <?php echo $row['names']; ?> </td>
<td> <?php echo $row['phone']; ?> </td>
<td> <?php echo $row['productsname']; ?> </td>
<td> <?php echo $row['quantity']; ?> </td>
<td> <?php echo $row['description']; ?> </td>


<td ><a href="deletet.php?id=<?php echo $row['Id'] ?>"> Delete</a>


</td>


</tr>



<?php } ?>
</table>

<div id="menu1">
<h1 class="title style3">Farmers Queries</h1>
</div>
<table>
<thead>
<tr>
	<th>ID </th>
	<th>FULL NAME</th>
	<th>PHONE</th>
	<th>PRODUCTS NAME</th>
	<th> QUANTITY </th>
	<th> DESCRIPTION </th>
	<th> DELETE </th>
	
	</tr>
	</thead>

<?php
require_once('connect.php');

$query = mysqli_query($connection, "SELECT * FROM `product_farmer`");
while ($row = mysqli_fetch_array($query)){
$no = $row['Id'];
?>

<tr>
<td> <?php echo $row['Id']; ?> </td>
<td> <?php echo $row['names']; ?> </td>
<td> <?php echo $row['phone']; ?> </td>
<td> <?php echo $row['productsname']; ?> </td>
<td> <?php echo $row['quantity']; ?> </td>
<td> <?php echo $row['description']; ?> </td>


<td ><a href="deletef.php?id=<?php echo $row['Id'] ?>"> Delete</a>
	

</td>


</tr>



<?php } ?>
</table>
</body>
</html>
<?php } else { echo "Login Required";} ?>
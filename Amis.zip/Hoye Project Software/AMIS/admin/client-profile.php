<?php
session_start();

include('connect.php');

if(isset($_SESSION['login_name'])){
	$name = $_SESSION['login_name'];

?>

<!DOCTYPE html>
<html>
<head>
<title>PROFILE</title>
<link href="css/profile.css" rel="stylesheet" type="text/css">
<link href="slider.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="slider.js"></script>
</head>
<body>
	
<div id="home">
<b id="welcome">Profile : <i><?php echo $name; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>

<p></p>
<div id="menu1">
<h1>Agriculture Market Information System </h1>
<ul class="menu nav">

		<li><a href="../index.php">HOME</a></li>
		<li><a href="about">MARKET ANALYSIS </a></li>
		<li><a href="about">NEWS</a></li>
  </ul>
</div>


<div id="content" class"tblform">

<table align="center" width="800">
<div style="color:#FF0000;" align="center"><?php if(isset($_GET['remark'])){
									if($_GET['remark']=="alreadytaken"){ echo "Products Registered Previously !!! Update new products"; }
									else
									if($_GET['remark']=="error"){ echo "Error in your input, Try again"; }
									else 
									if($_GET['remark']=="success"){ echo "Products Registered Succeccfully !!! Update new products"; }
								}	?>							
</div>
<form action="products.php" method="post" name="profile">
<th colspan="2" bordercolor="style:#000000"> Product Information <?php echo $name; ?></th>
<tr><td><label> Names:</label> </td> <td> <input type="text" name="names" Placeholder="Full Name" required="required" ></td></tr>
<tr><td><label> Phone:</label> </td> <td> <input type="text" name="phone" Placeholder="Mobile" required="required" ></td></tr>
<tr><td><label> Name Of Products:</label> </td> <td> <input type="text" name="productsname" Placeholder="Product Type" required="required" ></td></tr>
<tr><td><label> Quantity:</label></td> <td> <input type="text" name="quantity" Placeholder="quantity" required="required"></td></tr>
<tr><td><label> Products Description:</label></td> <td> <textarea cols="60" rows="5" name="description" Placeholder="Tell Us About Your Products" required="required"></textarea></td></tr>
<tr><td><label>Occupation:</label></td><td>
											<Select name="dropdown">
											<option > Select </option>
											<option value="trader" >Trader</option>
											<option value="farmer">Farmer</option></Select></td></tr>
<tr><td><label> Save</label></td> <td> <input name="save" type="submit" value="Save"></td></tr>
</form>
</table>
</div>

<footer>
		<div class="footer">
		&copy; festusoyefusi@gmail.com 2017. All right reserved.		</div>
</footer>

</body>
</html>

<?php } else { echo "Login Required";} ?>
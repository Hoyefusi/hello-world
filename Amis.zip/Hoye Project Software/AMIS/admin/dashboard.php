<?php
session_start();

include('connect.php');


if(isset($_SESSION['login_name'])){
	$name = $_SESSION['login_name'];


?>

<!DOCTYPE html>
<html>
<head>
<title>DASHBOARD</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="slider1.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="slider1.js"></script>
</head>
<body>
	
<div id="home">
<b id="welcome">Welcome : <i><?php echo $name; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>

<p></p>
<div id="menu1">
<h1>Agriculture Market Information System </h1>
<ul class="menu nav">

		<li><a href="dashboard.php">DASHBOARD</a></li>
		<li><a href="clientlogin.php">CLIENT PROFILE</a></li>
		<li><a href="view.php">VIEW</a></li> 
		<li><a href="message.php">MESSAGE</a></li> 
  </ul>
</div>
<!--#####################################-->
</br>
<div id="header1">
<div id="featured_slide">
  <div class="wrapper">
   <div id="sliderFrame">
        <div id="slider">
                <img src="Images/redifined.png" alt="Technique and Processes" width="1200" height="450" />
            <img src="Images/Access.png" alt="Educating Farmers on Food Security and Development" width="1200" height="450" />
            <img src="Images/fast.png" alt="Educating farmers on market information" width="1200" height="450" />
            <img src="Images/click.png" alt="Quality market products" width="1200" height="450" />        </div>
    </div>  
  </div>   
</div>
<header1>
<!--Container For Aside Design Below /-->
  						</br>
						<aside>
							<div class="outer">
								<h3>Register Farmer/Trader</h3>
								<div style="color:#FF0000;"><?php if(isset($_GET['remark'])){
									if($_GET['remark']=="alreadytaken"){ echo "Sorry Number is Registered"; }
									else
									if($_GET['remark']=="error"){ echo "Error in your input, Try again"; }
								}	?>							
								</div>
									<div class="inner">
										<form action="register.php" method="post">
										<label>Full_Name:</label>
											<input name="fullname" placeholder="Full_Name" type="text" required="required">
										<label>Phone:</label>
											<input name="phone" placeholder="Phone(Username)" type="text" required="required">
										<label>Password:</label>
											<input name="password" placeholder="**********" type="password" required="required">
										<label>E-Mail:</label>
											<input name="email" placeholder="email" type="text" required="required">
										<label>Occupation:</label>
											<Select name="dropdown">
											<option > Select </option>
											<option value="trader" >Trader</option>
											<option value="farmer">Farmer</option>
											</Select><br/>
											<p></p>
											<input name="submit" type="submit" value=" Register ">
										</form>
									</div>
							</div>
						</aside> 
</header1>
</div>
</br>



</body>
</html>

<?php } else { echo "Login Required";} ?>
<?php 

//declare usernamae and password
	$phone=$_POST['phone'];
 	$password=$_POST['password'];
 	$occupation=$_POST['dropdown'];
 
 //establishhing connection with database
 require_once("connect.php");
 
	if ($occupation=="farmer")
	{
		// query database login table to get username and password
		$query = "SELECT * FROM farmer WHERE phone='$phone' AND password='$password'";
		//variable result 
		$result = $connection->query($query) or die($connection.error);
	
	
		$row = $result->fetch_array(MYSQLI_ASSOC);
			
		 
		 //assigning phone as username into variable dbuser
		 //assigning password as pass into variable dpass
		 $dbcl= $row['phone'];
		 $dbps= $row['password'];
			

		 if (($dbcl == $phone) && ($dbps == $password ))
		{ 
			echo "you are in";
			session_start();
			$_SESSION['login_name'] = $phone;
			header("location: client-profile.php");
		}
		} else if ($occupation=="trader")
	{
		// query database login table to get username and password
		$query = "SELECT * FROM trader WHERE phone='$phone' AND password='$password'";
		//variable result 
		$result = $connection->query($query) or die($connection.error);
		
	
		$row = $result->fetch_array(MYSQLI_ASSOC);
			
		 
		 //assigning phone as username into variable dbuser
		 //assigning password as pass into variable dpass
		 $dbcl= $row['phone'];
		 $dbps= $row['password'];
			

		 if (($dbcl == $phone) && ($dbps == $password ))
		{ 
			echo "you are in";
			session_start();
			$_SESSION['login_name'] = $phone;
			header("location: client-profile.php");
		}
		}else{
	echo "not found";
	header("location: clientlogin.php?remark=error");
}
		
?>
<?php
session_start();
session_unset();

session_destroy();

echo "logged out....";
header("Refresh:3; ../index.php"); // Redirecting To Home Page

?>
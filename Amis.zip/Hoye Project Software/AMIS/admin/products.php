<?php

	// Define $Registeration Details
	 $names=$_POST['names'];
	 $phone=$_POST['phone'];
	 $productsname=$_POST['productsname']; 
	 $quantity=$_POST['quantity'];
	 $description=$_POST['description'];
	 $occupation=$_POST['dropdown'];
	// Establishing Connection with Server by passing server_name, user_id and password as a parameter
	require_once("connect.php");
	

	if ($occupation=="farmer")
	{
	
		$qr = "SELECT * FROM product_farmer WHERE productsname='$productsname'";
	
	$rs = $connection->query($qr);
	
	if(mysqli_num_rows($rs) > 0){
		header("location: client-profile.php?remark=alreadytaken");
		}
		else{
	//It wiil insert a row into Table Farmer DB`
$query = "INSERT INTO product_farmer(names, phone, productsname, quantity, description, occupation) 
	VALUES ('$names', '$phone', '$productsname','$quantity','$description','$occupation')";

		$data = $connection->query($query ) or die($connection.error);
		header("location: client-profile.php");
		}
	}
	else if($occupation=="trader")
	{
	$qr = "SELECT * FROM product_trader WHERE productsname='$productsname'";
	
	$rs = $connection->query($qr);
	
	if(mysqli_num_rows($rs) > 0){
		header("location: client-profile.php?remark=alreadytaken");
		}
		else{
	//It wiil insert a row into Table Farmer DB`
	$query = "INSERT INTO product_trader(names, phone, productsname, quantity, description, occupation) 
	VALUES ('$names', '$phone', '$productsname','$quantity','$description','$occupation')";

		$data = $connection->query($query ) or die($connection.error);
		header("location: client-profile.php");
		}
	
	}else
	{ header("location: client-profile.php?remark=error"); }
	
?>
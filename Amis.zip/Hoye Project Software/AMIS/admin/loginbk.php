v<?php 
require_once("connect.php");

//declare usernamae and password
 $username = $_POST['username'];
 $password = $_POST['password'];

// query database login table to get username and password
$query = "SELECT * FROM login WHERE Username='$username' AND Password='$password'";
//variable result 
$result = $connection->query($query) or die($connection.error);
echo "first position";

	$row = $result->fetch_array(MYSQLI_ASSOC);
	
	 echo "here";
	 $dbuser= $row['Username'];
	 $dbpass= $row['Password'];
	 
if (($dbuser == $username) && ($dbpass == $password ))
	{
	
		echo "you are in";
		session_start();
		$_SESSION['login_name'] = $username;
		header("location: dashboard.php");
		
	}else{
	echo "not found";
	header("location: login.php?remark=error");
}

?>
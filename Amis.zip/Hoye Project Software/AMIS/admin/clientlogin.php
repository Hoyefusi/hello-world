<!DOCTYPE html>
<html>
<head>
<title>CLIENT-LOGIN</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="slider.js"></script>
</head>
<body>

<p></p>
<div id="menu1">
<h1>Agriculture Market Information System </h1>
<ul class="menu nav">

		<li><a href="../index.php">HOME</a></li>
		<li><a href="clientlogin.php">CLIENT LOGIN</a></li> 
		
		<li><a href="login.php">ADMIN-LOGIN</a></li>
		
  </ul>
</div>
<!--#####################################-->
</br>
<div id="main">
<div id="h1s">
<h1> AGRICULTURE MARKET INFORMATION SYSTEM </h1>
</div>

<h2> <marquee> AMIS </marquee></h2>
<div id="login">

<h2>CLIENT LOGIN</h2>

<form action="clientloginbk.php" method="post">
	<p align="center"><div style="color:#FF0000;"><?php if(isset($_GET['remark'])){
	if($_GET['remark']=="error")
	{ echo "Login in Error, Try again!!!"; }
	 }?>
	</div></p>
	<label>Occupation:</label>
	<Select name="dropdown">
	<option > Select </option>
	<option value="trader" >Trader</option>
	<option value="farmer">Farmer</option>
	</Select><br/><p></p>
	<label>Phone:</label>
	<input name="phone" placeholder="Phone(Username)" type="text" required="required">
	<label>Password:</label>
	<input name="password" placeholder="**********" type="password" required="required">
	<p></p>
	<input name="submit" type="submit" value=" Login ">
	
	</form>
</div>
</div>
<footer>
		 <div id="homecontent">
    <ul>
      <li class="f active">
          <p class="readmore"> Contact Us</p>
		</li>
</footer>
</body>
</html>
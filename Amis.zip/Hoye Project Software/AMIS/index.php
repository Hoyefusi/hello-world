<!DOCTYPE html>
<html>
<head>
<title>INDEX</title>
<link href="styles/style.css" rel="stylesheet" type="text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.hoverIntent.js"></script>
<script type="text/javascript" src="scripts/jquery.hslides.1.0.js"></script>
<script type="text/javascript" src="scripts/jquery.hslides.setup.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />


<link href="theme/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="theme/1/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />

    <style type="text/css">
<!--
.style3 {font-size: 24px}
.style4 {color: #000000}
.style5 {
	color: #000000;
	font-family: "Times New Roman", Times, serif;
	font-size: 18px;
}
.style6 {
	font-size: 18px;
	color: #000000;
}
.style7 {width:920px; padding:15px 10px; background-color:#AEFDAE; border-left:10px solid #DFDFDF; border-right:10px solid #DFDFDF; border-radius:10px; display: block;}
-->
    </style>
</head>

<body>
<div id="menu1">
<h1 class="title style3">AGRICULTURE MARKET INFORMATION SYSTEM</h1>
</div>

<div class="menu">
<ul class="menu nav">

		<li><a href="index.php">HOME</a></li>
		<li><a href="admin/clientlogin.php">CLIENT LOGIN</a></li> 
		<li><a href="admin/login.php">ADMIN-LOGIN</a></li>
	
  </ul>
</div>

 <!-- below are the body contents /--#################
 ###############################################/-->

<div id="featured_slide">
  <div class="wrapper">
   <div id="sliderFrame">
        <div id="slider">
                <img src="Images/redifined.png" alt="Technique and Processes" />
            <img src="Images/Access.png" alt="Educating Farmers on Food Security and Development" />
            <img src="Images/fast.png" alt="Educating farmers on market information" />
            <img src="Images/click.png" alt="Quality market products" />        </div>
    </div>  
  </div>   
</div>

  <!-- below are the body contents /-->
	 <br class="clear" />
	 <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
    </div>
    <br class="clear" />
	
<!-- below are the Information and paragraphs contents /-->
<div id="homecontent">
  <div class="wrapper">
    <ul>
      <li>
        <h2 align="justify" class="title"><img src="images/server.png" alt="" />Agriculture Market Information System</h2>
        <p align="justify" class="style4">Market information is essential for agricultural development and to improve food security, particularly for small-scale producers and traders, who typically have limited access to, and understanding of market information and analysis.</p>
		<p align="justify" class="style4">The importance of the role of market information in terms of economic efficiency and performance as well as equity is widely acknowledged. It was observed in that accurate and timely market information enhances market performance by improving the knowledge of market actors. An equal balance of knowledge provides a more equal distribution of the gains from efficient market price formation.</p>
      </li>
      <li>
        <h2 class="title"><a href="marketanalysis.php"><img src="images/loading.gif" alt="" width="97" height="83" />Market Analysis</a></h2>
        <p align="justify"></p>
        </li>
	   <li class="last active">
        <h2 class="title"><a href="registeration.php"><img src="images/user1.png" alt="" />Register Now</a></h2>
		<p class="readmore">Register Now &raquo;</p>
		<span class="style6"><br class="clear" />
  </span>
	  </li>
    </ul>
    <div align="justify" class="style5">
     	
      <p><a href="news.php">The main purpose of Agricultural Marketing Information System (AMIS)</a> is to disseminate accurate and timely market information so as to support in marketing decision making and marketing efforts of entrepreneurs, farmers, government and development organizations.
        
        To disseminate timely, comprehensive, current and future price intelligence on agricultural commodities for better scientific decision-making by farming community, traders, firms and researchers. More specifically, providing price forecasts well in advance of sowing of major commodities and during harvesting helps the farmers in taking better sowing and selling decisions; </p>
    </div>
    <span class="style6"><br class="clear" />
  </span></div>
</div>
<div class="style6" id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
        </fieldset>
      </form>
</div>
    <span class="style6"><br class="clear" />
    <!-- ####################################################################################################### -->
    </span>
    <div class="style6" id="copyright">
  <div class="style7">
    <p align="center" class="fl_left">Copyright &copy; 2017 - All Rights Reserved  </p>
    <p align="center" class="fl_left">Computer Science 2015 - 2017 </p>
    <p align="center" class="fl_left">&trade; : PN/CS/15/0391 &reg; Oyefusi Damilare Festus</p>
  </div>
</div>
 
<footer>
		 <div id="homecontent">
    <ul>
      <li class="f active">
          <p class="readmore"> H.O.D Computer Science </p>
		<p class="readmore">Mrs. J. Soyemi</p>
      </li>
      <li>
           <p class="readmore"> Supervisor </p>
		<p class="readmore">Mr. Adesola Adesi</p>
        </li>
	   <li>
       <p class="readmore">Developer</p>
		<p class="readmore">Mr. Oyefusi Damilare Festus</p>
	  </li>
    </ul>
</footer>

    <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
    </script>
    </span>
</body>
</html>


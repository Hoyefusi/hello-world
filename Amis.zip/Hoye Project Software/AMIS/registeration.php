<!DOCTYPE html>
<html>
<head>
<title>REGISTERATION</title>
<link href="admin/style.css" rel="stylesheet" type="text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.hoverIntent.js"></script>
<script type="text/javascript" src="scripts/jquery.hslides.1.0.js"></script>
<script type="text/javascript" src="scripts/jquery.hslides.setup.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />


<link href="theme/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="theme/1/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />

    <style type="text/css">
<!--
.style3 {font-size: 24px}
.style4 {color: #000000}
.style5 {
	color: #000000;
	font-family: "Times New Roman", Times, serif;
	font-size: 18px;
}
.style6 {
	font-size: 18px;
	color: #000000;
}
.style7 {width:920px; padding:15px 10px; background-color:#AEFDAE; border-left:10px solid #DFDFDF; border-right:10px solid #DFDFDF; border-radius:10px; display: block;}
-->
    </style>
</head>

<body>
<div id="menu1">
<h1 class="title style3">AGRICULTURE MARKET INFORMATION SYSTEM</h1>
</div>

<div class="menu">
<ul class="menu nav">

		<li><a href="index.php">HOME</a></li>
		<li><a href="admin/clientlogin.php">CLIENT LOGIN</a></li> 
		<li><a href="about">MARKET ANALYSIS </a></li>
		<li><a href="admin/login.php">ADMIN-LOGIN</a></li>
		<li><a href="about">NEWS</a></li>
  </ul>
</div>

					<div id="homecontent">
  <div class="wrapper">	
								<h3>Register Farmer/Trader</h3>
								<div style="color:#FF0000;"><?php if(isset($_GET['remark'])){
									if($_GET['remark']=="alreadytaken"){ echo "Sorry Number is Registered"; }
									else
									if($_GET['remark']=="error"){ echo "Error in your input, Try again"; }
								}	?>							
								</div>
										<form action="registerbk.php" method="post">
										<label>Full_Name:</label>
											<input name="fullname" placeholder="Full_Name" type="text" required="required">
										<label>Phone:</label>
											<input name="phone" placeholder="Phone(Username)" type="text" required="required">
										<label>Password:</label>
											<input name="password" placeholder="**********" type="password" required="required">
										<label>E-Mail:</label>
											<input name="email" placeholder="email" type="text" required="required">
										<label>Occupation:</label>
											<Select name="dropdown">
											<option > Select </option>
											<option value="trader" >Trader</option>
											<option value="farmer">Farmer</option>
											</Select><br/>
											<p></p>
											<input name="submit" type="submit" value=" Register ">
										</form>
						</div>
						</div>
			    <span class="style6"><br class="clear" />
    <!-- ####################################################################################################### -->
    </span>
    <div class="style6" id="copyright">
  <div class="style7">
    <p align="center" class="fl_left">Copyright &copy; 2017 - All Rights Reserved  </p>
    <p align="center" class="fl_left">Computer Science 2015 - 2017 </p>
    <p align="center" class="fl_left">&trade; : PN/CS/15/0391 &reg; Oyefusi Damilare Festus</p>
  </div>
</div>
 